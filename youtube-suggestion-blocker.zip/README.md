# youtube-suggestion-blocker
removes youtube video suggestions